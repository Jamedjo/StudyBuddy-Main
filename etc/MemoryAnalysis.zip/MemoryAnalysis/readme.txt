See ImageIcon/explanation.txt for first test
See BufferedImage/explanation.txt for next test and the 2nd part of this test

See BufferedImage/explanaation.txt for analysis of results and reccommended actions. 
