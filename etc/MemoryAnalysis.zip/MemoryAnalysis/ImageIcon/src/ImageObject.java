import java.net.URL;
import java.awt.image.BufferedImage;
import java.awt.Graphics2D;
import java.awt.Image;
import java.io.File;
import javax.imageio.ImageIO;
import java.net.MalformedURLException;
import java.io.IOException;
import javax.swing.ImageIcon;
import java.awt.RenderingHints;



enum Orientation {Landscape,Portrait}
enum ImgSize {Thumb,Screen,Full;
    boolean isLarge(){
	if(this==Thumb) return false;
	else return true;
    }
    boolean isThumb(){
	return !isLarge();
    }
}

class ImageObject {//could be updated to take a File instead, or a javase7 path
    BufferedImage bImage = null;//depreciated
    ImageIcon imageIcon = null;//Full size image, may be maxed at size of screen. Flushed when not needed.
    ImageIcon thumbIcon = null;//Created when large created, not removed.
    URL urlAddress;
    String absolutePath;//Kept for error messages. Likely to be similar to urlAddress.toString()
    Orientation iOri;
    int width,height;
    //String imageID;
    //String title,filename,comments?
    static final int iconMaxW = 200;
    static final int iconMaxH = 200;

    ImageObject(String absoluteURL){
	if(absoluteURL.startsWith("///\\\\\\")){
	    String relativeURL = absoluteURL.substring(6);
	    //System.out.println(relativeURL +  " is relative and absolute is " + absoluteURL);
	    urlAddress = GUI.class.getResource(relativeURL); //could be null
	    absolutePath = urlAddress.toString();
	}
	else {
	    File file = new File(absoluteURL);
	    try{
		absolutePath = absoluteURL;
		urlAddress = file.toURI().toURL();
		//System.out.println(absoluteURL +  " is absolute and file is "+file.toString() +" and URL is " + urlAddress.toString());
	    } catch (MalformedURLException e){
		urlAddress = null;
		System.err.println("Image file " + absoluteURL + " could not be found " + "\nError was: " + e.toString());
	    }
	}
	if(urlAddress==null){
	    System.err.println("File could not be found at " + absoluteURL);
	}
	//ImageObjectConstructor();
    }

    ImageObject(URL urlAddress){
	absolutePath = urlAddress.toString();//should find absoluteURL for printing
	//ImageObjectConstructor();
    }

    //ImageObject(URL urlAddress, String absoluteURL){
    //	ImageObjectConstructor(urlAddress, absoluteURL);
    //}

    ImageIcon getIcon(ImgSize size){
	//gets thumbnail or full image
	if(size.isThumb()&&thumbIcon!=null) return thumbIcon;
	if(size.isLarge()&&imageIcon!=null) return imageIcon;
	//Build large icon and small icon, return relevent.
        try {
            bImage = ImageIO.read(urlAddress);//VERY BAD code, loads all images into limited memory

            imageIcon = new ImageIcon(urlAddress);
	    thumbIcon =  makeThumb(imageIcon);
            //File fileAddress = new File(relativeURL);
            //img = ImageIO.read(fileAddress)
	    setVars();
        } catch (IOException e) {
	    System.err.println("Error loading image " + absolutePath + "\nError was: " + e.toString());
	    setToXasFileNotFound();
	    //JOptionPane.showMessageDialog(parentPane,"Error Loading Image" + e.toString(),"Fatal Error",JOptionPane.ERROR_MESSAGE);
        } catch (IllegalArgumentException e) {
	    System.err.println("Image file " + absolutePath + " could not be found " + "\nError was: " + e.toString());
	    setToXasFileNotFound();
	} catch (NullPointerException e) {
	    System.err.println("Could not load image from file " + absolutePath + "\nError was: " + e.toString());
	    setToXasFileNotFound();
	}
	if(size.isLarge()) return imageIcon;
	return thumbIcon;
    }

    ImageIcon makeThumb(ImageIcon bigIcon){
	int[] iconWH = scaleToMax(bigIcon.getIconWidth(),bigIcon.getIconHeight(),iconMaxW,iconMaxH);

	Image tempimage = bigIcon.getImage();
	
        Graphics2D g2 = (new BufferedImage(iconWH[0],iconWH[1],BufferedImage.TYPE_INT_RGB)).createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2.drawImage(tempimage, 0, 0, iconWH[0],iconWH[1], null);
        g2.dispose();
	
	
	
	
	
	
	return new ImageIcon(tempimage);
	
	
    }


    void clearMem(){
	//clears the full size image.
	bImage.flush();
	bImage = null;
	imageIcon = null;
    }

    void setVars(){
	width = imageIcon.getIconWidth();
	height = imageIcon.getIconHeight();
	if(height<width) iOri = Orientation.Landscape;
	else iOri = Orientation.Portrait;
    }

    void setToXasFileNotFound(){
	//set image to error icon
	//improvement: set the buffered image to a java graphics drawn X icon
	try{
	bImage = ImageIO.read(SysIcon.Error.imgURL);
	imageIcon = new ImageIcon(SysIcon.Error.imgURL);
	thumbIcon = new ImageIcon(SysIcon.Error.imgURL);
	setVars();
	} catch (IOException e) {
	    System.err.println("Error loading image: " + e.toString());
	    //JOptionPane.showMessageDialog(parentPane,"Error Loading Image" + e.toString(),"Fatal Error",JOptionPane.ERROR_MESSAGE);
        } 
    }

    //Finds maximum with and height somthing can be scaled to, without changing aspect ratio
    //Takes the dimensions of the object inW and inH
    //and the dimensions of the box it is to be fitted into maxW and maxH
    //Returns (Width,Height) as an array of two integers.
    //Not sure which class it belongs in.
    static int[] scaleToMax(int inW, int inH, int maxW, int maxH) {
	float f_inW,f_inH,f_maxW,f_maxH;
	f_inW = inW;
	f_inH = inH;
	f_maxW = maxW;
	f_maxH = maxH;
	int[] outWH = new int[2];
	if ( (f_inW/f_inH)<(f_maxW/f_maxH) ) {
	    //narrower at same scale
	    outWH[1] = maxH;
	    outWH[0] = Math.round((f_maxH / f_inH)* f_inW);
	}
	else {
	    //wider at same scale
	    outWH[0] = maxW;
	    outWH[1] = Math.round(( f_maxW / f_inW)* f_inH);
	}
	return outWH;
    }
}
